## Projeto de Biblioteca

Este projeto tem como objetivo ser um sistema de biblioteca simples, onde existem dois tipos de usuários que tem permissões diferentes:

- Bibliotecário: pode criar, editar, excluir e listar os livros, além de poder confirmar o pedido de reserva de um aluno;
- Aluno: pode listar os livros e pedir a reserva dos livros

A intenção é deixar o escopo mais fechado e com o passar do tempo avaliar a possibilidade de incrementar mais funções ao sistema.
